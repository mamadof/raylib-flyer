#include "sounds.h"
#include <raylib.h>

const char *gca_soundFiles[] = {
  "data/tagh.mp3",
  "data/tagh_khar.mp3"
};

void playGameSound(GameSounds sound)
{
    
}

void loadGameSounds()
{

}