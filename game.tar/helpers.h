#ifndef HELPERS_H
#define HELPERS_H
#include <raylib.h>


Color GetRandomColor();
Color GetRandomColorNoAlpha();

#endif //HELPERS_H