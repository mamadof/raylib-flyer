#ifndef RENDER_H
#define RENDER_H

void renderAll();
void drawGrid();
void drawGameBoarder();

#endif//RENDER_H